const Data = require("../data/data.json");

export const Config = {
  name: "Perfectz Digital",
  url: "http://localhost:3000/",
  linkedInUrl: "https://www.linkedin.com/company/perfectz-digital",
  emailAddress: "hello@perfectzdigital.com",
  data: Data,
};
